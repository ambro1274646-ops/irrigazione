<?php
/**
 * get_statistiche.php
 *
 * Ritorna in JSON le letture di un sensore (terreno / aria / pioggia)
 * per un dato impianto, filtrate sugli ultimi N giorni. Usato via fetch()
 * da dashboard_impianto.php per disegnare i grafici SVG.
 *
 * GET /get_statistiche.php?id_impianto=1&tipo=terreno&giorni=7
 */

require_once __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');

$utente = autentica_utente();

$idImpianto = (int)($_GET['id_impianto'] ?? 0);
$tipo       = $_GET['tipo'] ?? '';
$giorni     = max(1, min(365, (int)($_GET['giorni'] ?? 7)));

$impianto = trova_impianto_di_utente($utente, $idImpianto);
if (!$impianto) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'errore' => 'Impianto non autorizzato']);
    exit;
}

// Whitelist esplicita di tabella/colonna per ogni tipo di statistica:
// evita qualsiasi rischio di SQL injection tramite il parametro `tipo`,
// che non viene MAI concatenato direttamente nella query.
$mappaTabelle = [
    'terreno' => ['tabella' => 'dati_terreno', 'colonna' => 'valore_umidita_terreno'],
    'aria'    => ['tabella' => 'dati_aria',    'colonna' => 'valore_umidita_aria'],
    'pioggia' => ['tabella' => 'dati_pioggia', 'colonna' => 'mm_pioggia'],
];

if (!isset($mappaTabelle[$tipo])) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'errore' => 'Tipo statistica non valido']);
    exit;
}

$tabella = $mappaTabelle[$tipo]['tabella'];
$colonna = $mappaTabelle[$tipo]['colonna'];

$conn = db_connect_impianto($impianto['nome_db_impianto']);

// Verifica che la tabella esista già (utile finché la migrazione delle
// nuove tabelle sensori non è stata ancora eseguita su tutti gli impianti):
// evita un errore SQL grezzo e ritorna semplicemente "nessun dato".
$checkTabella = $conn->query("SHOW TABLES LIKE '" . $conn->real_escape_string($tabella) . "'");
if ($checkTabella->num_rows === 0) {
    echo json_encode(['ok' => true, 'punti' => []]);
    $conn->close();
    exit;
}

$sql = "SELECT data_ora, `$colonna` AS valore FROM `$tabella`
        WHERE data_ora >= (NOW() - INTERVAL ? DAY)
        ORDER BY data_ora ASC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $giorni);
$stmt->execute();
$res = $stmt->get_result();

$punti = [];
while ($row = $res->fetch_assoc()) {
    if ($row['valore'] === null) continue;
    $punti[] = [
        'x' => $row['data_ora'],
        'y' => (float)$row['valore'],
    ];
}
$stmt->close();
$conn->close();

echo json_encode(['ok' => true, 'punti' => $punti]);
