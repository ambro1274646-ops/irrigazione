<?php
/**
 * config.php
 *
 * Configurazione centralizzata: connessione al database "master"
 * (if0_42967232_irrigazione_db) + funzioni di autenticazione riusate da
 * dashboard_home.php, dashboard_impianto.php e dagli endpoint AJAX.
 *
 * Le credenziali sono le stesse già usate in dashboard.php / login.php /
 * schedulazione.php: le ho semplicemente centralizzate qui per non
 * duplicarle in ogni file. Se in futuro cambiano, si modificano in un
 * unico posto.
 */

$host     = "sql300.infinityfree.com";
$username = "if0_42967232";
$password = "Ambro666Ambro";
$database = "if0_42967232_irrigazione_db";

/**
 * Apre una connessione al database principale (utenti, super_utenti, cookies, impianti).
 */
function db_connect_main(): mysqli {
    global $host, $username, $password, $database;
    $conn = new mysqli($host, $username, $password, $database);
    if ($conn->connect_error) {
        error_log("DB connect error: " . $conn->connect_error);
        http_response_code(500);
        exit("Errore interno");
    }
    $conn->set_charset("utf8mb4");
    return $conn;
}

/**
 * Apre una connessione al database specifico di un impianto
 * (es. if0_42967232_irrigazione_db_impianto_generico), quello che contiene
 * schedulazione, dati_terreno, dati_aria, dati_pioggia.
 */
function db_connect_impianto(string $nome_db_impianto): mysqli {
    global $host, $username, $password;
    $conn = new mysqli($host, $username, $password, $nome_db_impianto);
    if ($conn->connect_error) {
        error_log("DB connect error (impianto): " . $conn->connect_error);
        http_response_code(500);
        exit("Errore interno");
    }
    $conn->set_charset("utf8mb4");
    return $conn;
}

/**
 * Verifica il cookie "token" (stessa logica già presente in dashboard.php).
 * Se valido, ritorna i dati completi dell'utente loggato (riga della
 * tabella `utenti`, con anagrafica azienda/logo inclusi).
 * Se non valido, fa redirect al login e termina lo script.
 */
function autentica_utente(): array {
    $token = $_COOKIE['token'] ?? null;

    if ($token === null || $token === '') {
        header("Location: /index.html?errore=non_loggato");
        exit;
    }

    $conn = db_connect_main();

    $stmt = $conn->prepare("SELECT username FROM cookies WHERE valore = ? LIMIT 1");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $cookieRow = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$cookieRow) {
        setcookie("token", "", [
            'expires'  => time() - 3600,
            'path'     => '/',
            'secure'   => true,
            'httponly' => true,
            'samesite' => 'Strict',
        ]);
        $conn->close();
        header("Location: /index.html?errore=token_invalid");
        exit;
    }

    $stmt = $conn->prepare(
        "SELECT id_utente, username, nome_azienda, logo_url, super_user, id_impianto, nome_db_impianto
         FROM utenti WHERE username = ? LIMIT 1"
    );
    $stmt->bind_param("s", $cookieRow['username']);
    $stmt->execute();
    $utente = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    $conn->close();

    if (!$utente) {
        header("Location: /index.html?errore=utente_non_trovato");
        exit;
    }

    return $utente;
}

/**
 * Ritorna l'elenco dei sistemi di irrigazione associati all'utente loggato.
 * - Utente normale (super_user = 'f'): un solo impianto, quello indicato
 *   direttamente sulla riga `utenti`.
 * - Super utente (super_user = 't'): tutti gli impianti presenti nella
 *   tabella `super_utenti` per il suo id_utente.
 *
 * Ogni elemento ritornato ha: id_impianto, nome_db_impianto, nome_impianto.
 */
function elenco_impianti_utente(array $utente): array {
    $conn = db_connect_main();
    $impianti = [];

    if ($utente['super_user'] === 't') {
        $stmt = $conn->prepare(
            "SELECT su.id_impianto, su.nome_db_impianto,
                    COALESCE(i.nome_impianto, CONCAT('Impianto #', su.id_impianto)) AS nome_impianto
             FROM super_utenti su
             LEFT JOIN impianti i ON i.id_impianto = su.id_impianto
             WHERE su.id_utente = ?"
        );
        $stmt->bind_param("i", $utente['id_utente']);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) {
            $impianti[] = $row;
        }
        $stmt->close();
    } else {
        $stmt = $conn->prepare(
            "SELECT COALESCE(?, 0) AS id_impianto, ? AS nome_db_impianto,
                    COALESCE((SELECT nome_impianto FROM impianti WHERE id_impianto = ?), CONCAT('Impianto #', ?)) AS nome_impianto"
        );
        $stmt->bind_param(
            "isii",
            $utente['id_impianto'],
            $utente['nome_db_impianto'],
            $utente['id_impianto'],
            $utente['id_impianto']
        );
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) {
            $impianti[] = $row;
        }
        $stmt->close();
    }

    $conn->close();
    return $impianti;
}

/**
 * Recupera i dati (id_impianto, nome_db_impianto, nome_impianto) di UN
 * impianto specifico, verificando che appartenga davvero all'utente
 * loggato (sicurezza: evita che un utente acceda a impianti altrui
 * semplicemente cambiando l'id nell'URL).
 */
function trova_impianto_di_utente(array $utente, int $id_impianto): ?array {
    foreach (elenco_impianti_utente($utente) as $imp) {
        if ((int)$imp['id_impianto'] === $id_impianto) {
            return $imp;
        }
    }
    return null;
}

function h(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}
