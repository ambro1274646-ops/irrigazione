<?php
require_once __DIR__ . '/config.php';

$utente   = autentica_utente();
$impianti = elenco_impianti_utente($utente);

$nomeAzienda = $utente['nome_azienda'] ?: $utente['username'];
$logoUrl     = $utente['logo_url'];
?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<title>I miei sistemi di irrigazione</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/style.css">
</head>
<body>

<div class="app-shell">
  <div class="main-col">

    <div class="topbar">
      <div class="brand">
        <div class="brand-logo">
          <?php if ($logoUrl): ?>
            <img src="<?= h($logoUrl) ?>" alt="Logo <?= h($nomeAzienda) ?>">
          <?php else: ?>
            <svg viewBox="0 0 24 24" fill="none">
              <path d="M12 21c0-6 4-8 8-9-1 6-3 9-8 9Z" fill="#eafff4"/>
              <path d="M12 21c0-7-4-10-9-11 1 7 4 11 9 11Z" fill="#d8f6e8" fill-opacity=".55"/>
            </svg>
          <?php endif; ?>
        </div>
        <div class="brand-text">
          <div class="company"><?= h($nomeAzienda) ?></div>
          <div class="tagline">Pannello di controllo irrigazione</div>
        </div>
      </div>

      <div class="topbar-right">
        <span class="pill"><span class="dot"></span> Sistemi online</span>
      </div>
    </div>

    <div class="hr"></div>

    <h1 class="section-title">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22c5-1.5 7-6 7-10a7 7 0 1 0-14 0c0 4 2 8.5 7 10Z"/><path d="M12 12v6"/></svg>
      I miei sistemi di irrigazione
    </h1>
    <p class="section-sub">Seleziona un impianto per vedere schedulazione e statistiche in tempo reale.</p>

    <?php if (empty($impianti)): ?>
      <div class="empty-state">
        Nessun sistema di irrigazione risulta ancora collegato a questo account.
      </div>
    <?php else: ?>
      <div class="systems-grid">
        <?php foreach ($impianti as $imp): ?>
          <button class="system-card" onclick="location.href='/dashboard_impianto.php?id=<?= (int)$imp['id_impianto'] ?>'">
            <div class="system-card-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 20h16"/><path d="M7 20V10l5-6 5 6v10"/><path d="M10 20v-5h4v5"/></svg>
            </div>
            <div class="system-card-name"><?= h($imp['nome_impianto']) ?></div>
            <div class="system-card-meta"><span class="dot"></span> Attivo</div>
            <div class="system-card-go">
              Apri dashboard
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M5 12h13"/><path d="M13 6l6 6-6 6"/></svg>
            </div>
          </button>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

  </div>

  <aside class="sidebar">
    <div class="sidebar-title">Menu</div>
    <button class="side-btn" onclick="location.href='/statistiche_generali.php'">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3v18h18"/><path d="M7 15l4-5 3 3 5-7"/></svg>
      Statistiche generali
    </button>
    <button class="side-btn ai" onclick="location.href='/consigli_ai.php'">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l1.8 4.6L18 8l-4.2 1.4L12 14l-1.8-4.6L6 8l4.2-1.4L12 2Z"/><path d="M19 15l.9 2.1L22 18l-2.1.9L19 21l-.9-2.1L16 18l2.1-.9L19 15Z"/></svg>
      Consigli AI
    </button>
    <button class="side-btn" onclick="location.href='/contattaci.php'">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16v16H4z" opacity="0"/><path d="M4 6l8 7 8-7"/><rect x="3" y="5" width="18" height="14" rx="2.5"/></svg>
      Contattaci
    </button>
    <button class="side-btn logout" onclick="location.href='/logout.php'">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/></svg>
      Log-out
    </button>
  </aside>
</div>

</body>
</html>
