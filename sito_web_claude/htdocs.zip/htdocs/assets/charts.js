/**
 * assets/charts.js
 * Renderer di grafici SVG "a mano", senza librerie esterne — stessa scelta
 * già adottata nel README della bozza precedente ("grafici SVG senza
 * dipendenze esterne"). Pensato per piccole serie temporali (umidità
 * terreno/aria, piogge) con un look moderno: linea smussata + area
 * sfumata + animazione di comparsa.
 *
 * Uso:
 *   renderLineChart(containerEl, {
 *     points: [{x:"2026-09-15", y: 42}, ...],
 *     color: "green" | "blue" | "rain",
 *     unit: "%",
 *   });
 *
 *   renderBarChart(containerEl, {
 *     points: [{x:"Lun", y: 3}, ...],
 *     color: "rain",
 *     unit: "mm",
 *   });
 */

const CHART_COLORS = {
  green: { line: "#16a35f", fillFrom: "rgba(22,163,95,.30)", fillTo: "rgba(22,163,95,0)" },
  blue:  { line: "#0ea5e9", fillFrom: "rgba(14,165,233,.30)", fillTo: "rgba(14,165,233,0)" },
  rain:  { line: "#38bdf8", fillFrom: "rgba(56,189,248,.42)", fillTo: "rgba(56,189,248,0)" },
};

function _fmtAxisLabel(x){
  // accetta sia "YYYY-MM-DD HH:MM:SS" che etichette testuali (es. giorni)
  if (typeof x === "string" && /^\d{4}-\d{2}-\d{2}/.test(x)) {
    const d = new Date(x.replace(" ", "T"));
    if (!isNaN(d)) return d.toLocaleDateString("it-IT", { day: "2-digit", month: "2-digit" });
  }
  return x;
}

export function renderLineChart(container, { points, color = "green", unit = "" }) {
  if (!points || points.length === 0) {
    container.innerHTML = `<div class="chart-empty">Nessun dato disponibile</div>`;
    return;
  }
  const palette = CHART_COLORS[color] || CHART_COLORS.green;
  const W = 600, H = 190, padX = 8, padY = 22;
  const values = points.map(p => Number(p.y));
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;

  const stepX = (W - padX * 2) / Math.max(points.length - 1, 1);
  const coords = points.map((p, i) => {
    const x = padX + i * stepX;
    const y = padY + (H - padY * 2) * (1 - (Number(p.y) - min) / range);
    return [x, y];
  });

  // linea smussata (curva Catmull-Rom -> Bezier semplificata)
  let path = `M ${coords[0][0]},${coords[0][1]}`;
  for (let i = 0; i < coords.length - 1; i++) {
    const [x0, y0] = coords[i];
    const [x1, y1] = coords[i + 1];
    const mx = (x0 + x1) / 2;
    path += ` C ${mx},${y0} ${mx},${y1} ${x1},${y1}`;
  }
  const areaPath = `${path} L ${coords[coords.length - 1][0]},${H - padY} L ${coords[0][0]},${H - padY} Z`;

  const gradId = `grad-${color}-${Math.random().toString(36).slice(2, 8)}`;
  const lastPoint = coords[coords.length - 1];

  const labelEvery = Math.ceil(points.length / 6) || 1;
  const labels = points.map((p, i) =>
    i % labelEvery === 0 || i === points.length - 1
      ? `<text x="${coords[i][0]}" y="${H - 4}" font-size="10" fill="var(--text-soft)" text-anchor="middle">${_fmtAxisLabel(p.x)}</text>`
      : ""
  ).join("");

  container.innerHTML = `
    <svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="Grafico andamento ${unit}">
      <defs>
        <linearGradient id="${gradId}" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="${palette.fillFrom}"/>
          <stop offset="100%" stop-color="${palette.fillTo}"/>
        </linearGradient>
      </defs>
      <path d="${areaPath}" fill="url(#${gradId})" stroke="none">
        <animate attributeName="opacity" from="0" to="1" dur=".5s" fill="freeze"/>
      </path>
      <path d="${path}" fill="none" stroke="${palette.line}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"
            stroke-dasharray="900" stroke-dashoffset="900">
        <animate attributeName="stroke-dashoffset" from="900" to="0" dur=".9s" fill="freeze" calcMode="spline" keySplines="0.22 0.9 0.34 1"/>
      </path>
      <circle cx="${lastPoint[0]}" cy="${lastPoint[1]}" r="4.5" fill="${palette.line}" stroke="white" stroke-width="2">
        <animate attributeName="r" values="4.5;6;4.5" dur="2.2s" repeatCount="indefinite"/>
      </circle>
      ${labels}
    </svg>
  `;
}

export function renderBarChart(container, { points, color = "rain", unit = "" }) {
  if (!points || points.length === 0) {
    container.innerHTML = `<div class="chart-empty">Nessun dato disponibile</div>`;
    return;
  }
  const palette = CHART_COLORS[color] || CHART_COLORS.rain;
  const W = 600, H = 190, padX = 10, padY = 22, gap = 10;
  const values = points.map(p => Number(p.y));
  const max = Math.max(...values, 1);
  const barW = (W - padX * 2 - gap * (points.length - 1)) / points.length;

  const bars = points.map((p, i) => {
    const h = Math.max(((H - padY * 2) * (Number(p.y) / max)), 2);
    const x = padX + i * (barW + gap);
    const y = H - padY - h;
    return `
      <rect x="${x}" y="${H - padY}" width="${barW}" height="0" rx="6" fill="${palette.line}" opacity=".92">
        <animate attributeName="y" from="${H - padY}" to="${y}" dur=".6s" begin="${i * 0.04}s" fill="freeze" calcMode="spline" keySplines="0.22 0.9 0.34 1"/>
        <animate attributeName="height" from="0" to="${h}" dur=".6s" begin="${i * 0.04}s" fill="freeze" calcMode="spline" keySplines="0.22 0.9 0.34 1"/>
      </rect>
      <text x="${x + barW / 2}" y="${H - 4}" font-size="10" fill="var(--text-soft)" text-anchor="middle">${_fmtAxisLabel(p.x)}</text>
    `;
  }).join("");

  container.innerHTML = `
    <svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="Grafico frequenza ${unit}">
      ${bars}
    </svg>
  `;
}

export function showToast(message, kind = "info") {
  let el = document.getElementById("app-toast");
  if (!el) {
    el = document.createElement("div");
    el.id = "app-toast";
    el.className = "toast";
    document.body.appendChild(el);
  }
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(el._timer);
  el._timer = setTimeout(() => el.classList.remove("show"), 2800);
}
