<?php
require_once __DIR__ . '/config.php';

$utente   = autentica_utente();
$impianti = elenco_impianti_utente($utente);

function ultimaLettura(mysqli $conn, string $tabella, string $colonna): ?float {
    $check = $conn->query("SHOW TABLES LIKE '" . $conn->real_escape_string($tabella) . "'");
    if ($check->num_rows === 0) return null;
    $res = $conn->query("SELECT `$colonna` AS valore FROM `$tabella` ORDER BY data_ora DESC LIMIT 1");
    $row = $res->fetch_assoc();
    return $row ? (float)$row['valore'] : null;
}

$righe = [];
foreach ($impianti as $imp) {
    $conn = db_connect_impianto($imp['nome_db_impianto']);
    $righe[] = [
        'nome'    => $imp['nome_impianto'],
        'id'      => $imp['id_impianto'],
        'terreno' => ultimaLettura($conn, 'dati_terreno', 'valore_umidita_terreno'),
        'aria'    => ultimaLettura($conn, 'dati_aria', 'valore_umidita_aria'),
    ];
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<title>Statistiche generali</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/style.css">
<style>
  table{ width:100%; border-collapse:collapse; font-size:14px; }
  th, td{ text-align:left; padding:12px 14px; border-bottom:1px solid var(--border); }
  th{ color:var(--text-muted); font-size:12px; text-transform:uppercase; letter-spacing:.04em; }
  tr:last-child td{ border-bottom:none; }
  .link-cell a{ color:var(--blue-700); font-weight:700; text-decoration:none; }
  .link-cell a:hover{ text-decoration:underline; }
</style>
</head>
<body>
<div class="main-col" style="max-width:900px; margin:0 auto;">
  <a class="back-link" href="/dashboard_home.php">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M19 12H5"/><path d="M11 18l-6-6 6-6"/></svg>
    Torna alla dashboard
  </a>
  <h1 class="section-title" style="margin-top:10px;">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3v18h18"/><path d="M7 15l4-5 3 3 5-7"/></svg>
    Statistiche generali
  </h1>
  <p class="section-sub">Panoramica dell'ultima lettura di ogni impianto collegato al tuo account.</p>

  <div class="panel">
    <?php if (empty($righe)): ?>
      <div class="empty-state">Nessun impianto collegato.</div>
    <?php else: ?>
      <table>
        <thead>
          <tr><th>Impianto</th><th>Umidità terreno</th><th>Umidità aria</th><th></th></tr>
        </thead>
        <tbody>
          <?php foreach ($righe as $r): ?>
            <tr>
              <td><?= h($r['nome']) ?></td>
              <td><?= $r['terreno'] !== null ? number_format($r['terreno'], 1, ',', '') . ' %' : '—' ?></td>
              <td><?= $r['aria'] !== null ? number_format($r['aria'], 1, ',', '') . ' %' : '—' ?></td>
              <td class="link-cell"><a href="/dashboard_impianto.php?id=<?= (int)$r['id'] ?>">Apri →</a></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
