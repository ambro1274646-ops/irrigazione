<?php
require_once __DIR__ . '/config.php';
$utente = autentica_utente();
?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<title>Contattaci</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<div class="main-col" style="max-width:640px; margin:0 auto;">
  <a class="back-link" href="/dashboard_home.php">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M19 12H5"/><path d="M11 18l-6-6 6-6"/></svg>
    Torna alla dashboard
  </a>
  <h1 class="section-title" style="margin-top:10px;">Contattaci</h1>
  <p class="section-sub">Hai un problema con un impianto o un dubbio sulla schedulazione? Scrivici.</p>

  <div class="panel">
    <div class="panel-head"><h2>Assistenza</h2></div>
    <p style="color:var(--text-muted); font-size:14.5px; margin-bottom:18px;">
      Puoi scriverci direttamente via email indicando il nome del tuo impianto e il problema riscontrato.
    </p>
    <a class="btn-primary" href="mailto:assistenza@tuodominio.it?subject=Assistenza%20irrigazione">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="M4 6l8 7 8-7"/></svg>
      Scrivi una email
    </a>
  </div>
</div>
</body>
</html>
