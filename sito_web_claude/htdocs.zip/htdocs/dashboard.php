<?php
// dashboard.php è stata sostituita da dashboard_home.php.
// Questo file resta solo per compatibilità con eventuali link/bookmark
// già esistenti verso il vecchio URL.
header("Location: /dashboard_home.php");
exit;
