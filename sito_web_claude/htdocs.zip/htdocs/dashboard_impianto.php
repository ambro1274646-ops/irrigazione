<?php
require_once __DIR__ . '/config.php';

$utente = autentica_utente();

$id_impianto = (int)($_GET['id'] ?? 0);
$impianto = trova_impianto_di_utente($utente, $id_impianto);

if (!$impianto) {
    header("Location: /dashboard_home.php?errore=impianto_non_trovato");
    exit;
}

// Nomi giorni assumendo id_giorno 0 = Lunedì ... 6 = Domenica
// (coerente con l'ordine tipico usato nella tabella `schedulazione`;
// se nel tuo backend 0 = Domenica, basta cambiare questo array).
$nomiGiorni = ['Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab', 'Dom'];

// Lettura schedulazione corrente direttamente dal db dell'impianto,
// stessa logica/tabella già usata da schedulazione.php.
$connImp = db_connect_impianto($impianto['nome_db_impianto']);
$res = $connImp->query("SELECT id_giorno, ora_inizio, durata FROM schedulazione ORDER BY id_giorno ASC");
$schedulazione = [];
while ($row = $res->fetch_assoc()) {
    $schedulazione[(int)$row['id_giorno']] = $row;
}
$connImp->close();

$nomeAzienda = $utente['nome_azienda'] ?: $utente['username'];
$logoUrl     = $utente['logo_url'];
?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<title><?= h($impianto['nome_impianto']) ?> — Dashboard impianto</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/style.css">
</head>
<body>

<div class="app-shell" style="grid-template-columns:1fr;">
  <div class="main-col" style="max-width:1000px; margin:0 auto; width:100%;">

    <a class="back-link" href="/dashboard_home.php">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M19 12H5"/><path d="M11 18l-6-6 6-6"/></svg>
      Tutti i sistemi
    </a>

    <div class="impianto-topbar">
      <h1 class="impianto-name">
        <?= h($impianto['nome_impianto']) ?>
        <span class="badge-live"><span class="dot" style="width:6px;height:6px;border-radius:50%;background:var(--green-600);display:inline-block;"></span> In linea</span>
      </h1>
      <div class="brand-logo">
        <?php if ($logoUrl): ?>
          <img src="<?= h($logoUrl) ?>" alt="Logo <?= h($nomeAzienda) ?>">
        <?php else: ?>
          <svg viewBox="0 0 24 24" fill="none"><path d="M12 21c0-6 4-8 8-9-1 6-3 9-8 9Z" fill="#eafff4"/><path d="M12 21c0-7-4-10-9-11 1 7 4 11 9 11Z" fill="#d8f6e8" fill-opacity=".55"/></svg>
        <?php endif; ?>
      </div>
    </div>

    <div class="hr"></div>

    <!-- ================= SCHEDULAZIONE ================= -->
    <section class="panel" id="panel-schedulazione">
      <div class="panel-head">
        <h2>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="3"/><path d="M8 2v4M16 2v4M3 10h18"/></svg>
          Schedulazione
        </h2>
        <span class="panel-sub">Imposta orario e durata dell'irrigazione per ogni giorno della settimana</span>
      </div>

      <div class="schedule-grid" id="scheduleGrid">
        <?php foreach ($nomiGiorni as $idx => $nome):
            $row = $schedulazione[$idx] ?? null;
            $haOrario = $row && !empty($row['ora_inizio']);
        ?>
          <div class="day-card <?= $haOrario ? 'active' : '' ?>" data-giorno="<?= $idx ?>">
            <div class="day-name"><?= $nome ?></div>
            <div class="day-status"><?= $haOrario ? h($row['ora_inizio']) : 'NO' ?></div>
            <div class="day-duration"><?= $haOrario ? number_format((float)$row['durata'], 2, ',', '') . ' h' : '' ?></div>
            <button type="button" class="day-toggle" data-action="edit">Modifica</button>
            <div class="day-inputs">
              <label>Orario</label>
              <input type="time" class="input-orario" value="<?= $haOrario ? h($row['ora_inizio']) : '' ?>">
              <label>Durata (ore)</label>
              <input type="number" class="input-durata" min="0" max="24" step="0.25" value="<?= $haOrario ? h((string)$row['durata']) : '' ?>">
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <div class="schedule-actions">
        <button class="btn-primary" id="btnSalvaSchedulazione">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 13l4 4L19 7"/></svg>
          Salva schedulazione
        </button>
        <span class="save-status" id="saveStatus"></span>
      </div>

      <div class="recap-row" id="recapRow">
        <?php foreach ($nomiGiorni as $idx => $nome):
            $row = $schedulazione[$idx] ?? null;
            $haOrario = $row && !empty($row['ora_inizio']);
        ?>
          <span class="recap-chip <?= $haOrario ? 'on' : '' ?>">
            <?= $nome ?>: <?= $haOrario ? h($row['ora_inizio']) : 'NO' ?>
          </span>
        <?php endforeach; ?>
      </div>
    </section>

    <!-- ================= STATISTICHE ================= -->
    <div class="stats-stack">

      <section class="panel stat-panel" data-stat="terreno">
        <div class="panel-head">
          <h2><svg class="icon-soil" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 20h20"/><path d="M6 20V11l3-3 3 3v9"/><path d="M15 20v-6l3-2 3 2v6"/></svg>Umidità del terreno</h2>
          <div class="range-toggle" data-range-for="terreno">
            <button class="range-btn active" data-giorni="7">7 giorni</button>
            <button class="range-btn" data-giorni="30">30 giorni</button>
          </div>
        </div>
        <div class="stat-topline">
          <span class="stat-value soil" data-value-for="terreno">—</span>
          <span class="stat-trend flat" data-trend-for="terreno">—</span>
        </div>
        <div class="chart-wrap" data-chart-for="terreno"><div class="chart-loading">Caricamento dati…</div></div>
      </section>

      <section class="panel stat-panel" data-stat="aria">
        <div class="panel-head">
          <h2><svg class="icon-air" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 8h11a3 3 0 1 0-3-3"/><path d="M2 13h15a3 3 0 1 1-3 3"/><path d="M4 18h9a2.5 2.5 0 1 1-2.5 2.5"/></svg>Umidità dell'aria</h2>
          <div class="range-toggle" data-range-for="aria">
            <button class="range-btn active" data-giorni="7">7 giorni</button>
            <button class="range-btn" data-giorni="30">30 giorni</button>
          </div>
        </div>
        <div class="stat-topline">
          <span class="stat-value air" data-value-for="aria">—</span>
          <span class="stat-trend flat" data-trend-for="aria">—</span>
        </div>
        <div class="chart-wrap" data-chart-for="aria"><div class="chart-loading">Caricamento dati…</div></div>
      </section>

      <section class="panel stat-panel" data-stat="pioggia">
        <div class="panel-head">
          <h2><svg class="icon-rain" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 13a5 5 0 0 0-9.6-2 4.5 4.5 0 0 0 .6 9h9a3.5 3.5 0 0 0 0-7Z"/><path d="M8 19l-1 2M12 19l-1 2M16 19l-1 2"/></svg>Frequenza piogge</h2>
          <div class="range-toggle" data-range-for="pioggia">
            <button class="range-btn active" data-giorni="7">7 giorni</button>
            <button class="range-btn" data-giorni="30">30 giorni</button>
          </div>
        </div>
        <div class="stat-topline">
          <span class="stat-value rain" data-value-for="pioggia">—</span>
          <span class="stat-trend flat" data-trend-for="pioggia">—</span>
        </div>
        <div class="chart-wrap" data-chart-for="pioggia"><div class="chart-loading">Caricamento dati…</div></div>
      </section>

    </div>

  </div>
</div>

<script type="module">
import { renderLineChart, renderBarChart, showToast } from '/assets/charts.js';

const ID_IMPIANTO = <?= (int)$impianto['id_impianto'] ?>;

/* ---------------- Schedulazione: editing UI ---------------- */
document.querySelectorAll('.day-toggle').forEach(btn => {
  btn.addEventListener('click', () => {
    const card = btn.closest('.day-card');
    card.classList.toggle('editing');
    btn.textContent = card.classList.contains('editing') ? 'Chiudi' : 'Modifica';
  });
});

document.getElementById('btnSalvaSchedulazione').addEventListener('click', async () => {
  const statusEl = document.getElementById('saveStatus');
  const btn = document.getElementById('btnSalvaSchedulazione');
  const giorni = [...document.querySelectorAll('.day-card')].map(card => {
    const giorno = parseInt(card.dataset.giorno, 10);
    const orario = card.querySelector('.input-orario').value || null;
    const durataRaw = card.querySelector('.input-durata').value;
    const durata = orario && durataRaw !== '' ? parseFloat(durataRaw) : null;
    return { giorno, orario, durata };
  });

  btn.disabled = true;
  statusEl.textContent = 'Salvataggio in corso…';
  statusEl.className = 'save-status';

  try {
    const res = await fetch('/salva_schedulazione.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id_impianto: ID_IMPIANTO, giorni }),
    });
    const data = await res.json();
    if (!res.ok || !data.ok) throw new Error(data.errore || 'Errore di salvataggio');

    statusEl.textContent = 'Schedulazione salvata ✓';
    statusEl.className = 'save-status ok';
    showToast('Schedulazione aggiornata');

    // aggiorna recap + card senza ricaricare la pagina
    const nomiGiorni = ['Lun','Mar','Mer','Gio','Ven','Sab','Dom'];
    const recap = document.getElementById('recapRow');
    recap.innerHTML = giorni.map(g => {
      const on = !!g.orario;
      return `<span class="recap-chip ${on ? 'on' : ''}">${nomiGiorni[g.giorno]}: ${on ? g.orario : 'NO'}</span>`;
    }).join('');

    giorni.forEach(g => {
      const card = document.querySelector(`.day-card[data-giorno="${g.giorno}"]`);
      const on = !!g.orario;
      card.classList.toggle('active', on);
      card.classList.remove('editing');
      card.querySelector('.day-toggle').textContent = 'Modifica';
      card.querySelector('.day-status').textContent = on ? g.orario : 'NO';
      card.querySelector('.day-duration').textContent = on ? `${Number(g.durata).toFixed(2).replace('.', ',')} h` : '';
    });
  } catch (err) {
    statusEl.textContent = 'Errore nel salvataggio';
    statusEl.className = 'save-status err';
    showToast('Errore: ' + err.message);
  } finally {
    btn.disabled = false;
  }
});

/* ---------------- Statistiche: caricamento + grafici ---------------- */
const STAT_CONFIG = {
  terreno: { color: 'green', unit: '%', chartType: 'line' },
  aria:    { color: 'blue',  unit: '%', chartType: 'line' },
  pioggia: { color: 'rain',  unit: 'mm', chartType: 'bar' },
};

async function caricaStatistica(tipo, giorni = 7) {
  const cfg = STAT_CONFIG[tipo];
  const chartEl = document.querySelector(`[data-chart-for="${tipo}"]`);
  const valueEl = document.querySelector(`[data-value-for="${tipo}"]`);
  const trendEl = document.querySelector(`[data-trend-for="${tipo}"]`);

  chartEl.innerHTML = '<div class="chart-loading">Caricamento dati…</div>';

  try {
    const res = await fetch(`/get_statistiche.php?id_impianto=${ID_IMPIANTO}&tipo=${tipo}&giorni=${giorni}`);
    const data = await res.json();
    if (!data.ok) throw new Error();

    const punti = data.punti || [];
    if (punti.length === 0) {
      chartEl.innerHTML = '<div class="chart-empty">Ancora nessuna lettura per questo sensore</div>';
      valueEl.textContent = '—';
      trendEl.textContent = 'Nessun dato';
      trendEl.className = 'stat-trend flat';
      return;
    }

    if (cfg.chartType === 'line') {
      renderLineChart(chartEl, { points: punti, color: cfg.color, unit: cfg.unit });
      const ultimo = punti[punti.length - 1].y;
      valueEl.textContent = `${ultimo.toFixed(1)} ${cfg.unit}`;
      const primo = punti[0].y;
      const delta = ultimo - primo;
      trendEl.textContent = `${delta >= 0 ? '+' : ''}${delta.toFixed(1)} ${cfg.unit} nel periodo`;
      trendEl.className = 'stat-trend ' + (delta > 0.2 ? 'up' : delta < -0.2 ? 'down' : 'flat');
    } else {
      renderBarChart(chartEl, { points: punti, color: cfg.color, unit: cfg.unit });
      const totale = punti.reduce((s, p) => s + p.y, 0);
      const eventi = punti.filter(p => p.y > 0).length;
      valueEl.textContent = `${totale.toFixed(1)} ${cfg.unit}`;
      trendEl.textContent = `${eventi} giorni di pioggia`;
      trendEl.className = 'stat-trend ' + (eventi > 0 ? 'up' : 'flat');
    }
  } catch (e) {
    chartEl.innerHTML = '<div class="chart-empty">Dati non disponibili al momento</div>';
  }
}

document.querySelectorAll('.range-toggle').forEach(toggle => {
  const tipo = toggle.dataset.rangeFor;
  toggle.querySelectorAll('.range-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      toggle.querySelectorAll('.range-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      caricaStatistica(tipo, parseInt(btn.dataset.giorni, 10));
    });
  });
});

['terreno', 'aria', 'pioggia'].forEach(tipo => caricaStatistica(tipo, 7));
</script>

</body>
</html>
