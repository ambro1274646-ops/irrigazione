<?php
/**
 * salva_schedulazione.php
 *
 * Riceve (POST, JSON) le modifiche alla schedulazione settimanale fatte da
 * dashboard_impianto.php e le scrive nella tabella `schedulazione` del
 * database dell'impianto corretto. Non tocca la logica di lettura già
 * esistente in schedulazione.php (che resta invariata e continua a
 * funzionare per eventuali altri client, es. il coordinatore).
 *
 * Payload atteso:
 * {
 *   "id_impianto": 1,
 *   "giorni": [
 *     { "giorno": 0, "orario": "19:45", "durata": 1.3 },
 *     { "giorno": 1, "orario": null,     "durata": null },
 *     ...
 *   ]
 * }
 */

require_once __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'errore' => 'Metodo non consentito']);
    exit;
}

$utente = autentica_utente();

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'errore' => 'Payload non valido']);
    exit;
}

$idImpianto = (int)($input['id_impianto'] ?? 0);
$giorni     = $input['giorni'] ?? [];

// Sicurezza: verifica che l'impianto richiesto appartenga davvero all'utente loggato.
$impianto = trova_impianto_di_utente($utente, $idImpianto);
if (!$impianto) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'errore' => 'Impianto non autorizzato per questo utente']);
    exit;
}

if (!is_array($giorni) || count($giorni) === 0) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'errore' => 'Nessun giorno da salvare']);
    exit;
}

$conn = db_connect_impianto($impianto['nome_db_impianto']);

$stmt = $conn->prepare("UPDATE schedulazione SET ora_inizio = ?, durata = ? WHERE id_giorno = ?");

foreach ($giorni as $g) {
    $idGiorno = (int)($g['giorno'] ?? -1);
    if ($idGiorno < 0 || $idGiorno > 6) {
        continue; // ignora indici fuori range invece di far fallire l'intero salvataggio
    }

    $orario = trim((string)($g['orario'] ?? ''));
    $orario = $orario === '' ? null : $orario;

    $durata = $g['durata'] ?? null;
    $durata = ($orario === null || $durata === null || $durata === '') ? null : (float)$durata;

    $stmt->bind_param("sdi", $orario, $durata, $idGiorno);
    $stmt->execute();
}

$stmt->close();
$conn->close();

echo json_encode(['ok' => true]);
