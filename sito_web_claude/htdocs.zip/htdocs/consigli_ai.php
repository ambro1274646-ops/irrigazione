<?php
/**
 * consigli_ai.php
 *
 * Versione iniziale "smart" dei consigli: legge le ultime letture di
 * ciascun impianto (terreno / aria / pioggia) e genera suggerimenti con
 * regole semplici. È già collegata alle tabelle sensori reali, quindi in
 * futuro basta sostituire generaConsigli() con una chiamata a un vero
 * modello AI (es. Claude via API) passandogli gli stessi dati, senza
 * toccare il resto della pagina.
 */

require_once __DIR__ . '/config.php';

$utente   = autentica_utente();
$impianti = elenco_impianti_utente($utente);

function ultimaLettura(mysqli $conn, string $tabella, string $colonna): ?float {
    $check = $conn->query("SHOW TABLES LIKE '" . $conn->real_escape_string($tabella) . "'");
    if ($check->num_rows === 0) return null;
    $res = $conn->query("SELECT `$colonna` AS valore FROM `$tabella` ORDER BY data_ora DESC LIMIT 1");
    $row = $res->fetch_assoc();
    return $row ? (float)$row['valore'] : null;
}

function generaConsigli(?float $terreno, ?float $aria): array {
    $consigli = [];

    if ($terreno === null) {
        $consigli[] = ['tipo' => 'info', 'testo' => 'Nessun dato di umidità del terreno disponibile: verifica che il sensore sia collegato.'];
    } elseif ($terreno < 25) {
        $consigli[] = ['tipo' => 'alert', 'testo' => "Il terreno risulta piuttosto secco ({$terreno}%). Valuta di aumentare la durata dell'irrigazione nei prossimi giorni."];
    } elseif ($terreno > 70) {
        $consigli[] = ['tipo' => 'warn', 'testo' => "Il terreno è molto umido ({$terreno}%). Puoi ridurre o saltare l'irrigazione programmata per evitare ristagni."];
    } else {
        $consigli[] = ['tipo' => 'ok', 'testo' => "Il livello di umidità del terreno ({$terreno}%) è in un buon range: la schedulazione attuale sembra adeguata."];
    }

    if ($aria !== null) {
        if ($aria < 30) {
            $consigli[] = ['tipo' => 'warn', 'testo' => "L'aria è molto secca ({$aria}%): in giornate calde può aumentare l'evaporazione, considera un controllo più frequente del terreno."];
        } elseif ($aria > 80) {
            $consigli[] = ['tipo' => 'info', 'testo' => "Umidità dell'aria alta ({$aria}%): rischio maggiore di malattie fungine sulle colture, arieggia se possibile."];
        }
    }

    return $consigli;
}

$schedeConsigli = [];
foreach ($impianti as $imp) {
    $conn = db_connect_impianto($imp['nome_db_impianto']);
    $terreno = ultimaLettura($conn, 'dati_terreno', 'valore_umidita_terreno');
    $aria    = ultimaLettura($conn, 'dati_aria', 'valore_umidita_aria');
    $conn->close();

    $schedeConsigli[] = [
        'nome' => $imp['nome_impianto'],
        'consigli' => generaConsigli($terreno, $aria),
    ];
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<title>Consigli AI</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/style.css">
<style>
  .advice-card{ display:flex; gap:12px; padding:14px 16px; border-radius:14px; margin-bottom:10px; font-size:14px; }
  .advice-card.ok{ background:var(--green-100); color:var(--green-700); }
  .advice-card.warn{ background:#fff4e0; color:#9a6a12; }
  .advice-card.alert{ background:#fde8e3; color:#a3401f; }
  .advice-card.info{ background:var(--blue-100); color:var(--blue-700); }
</style>
</head>
<body>
<div class="main-col" style="max-width:760px; margin:0 auto;">
  <a class="back-link" href="/dashboard_home.php">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M19 12H5"/><path d="M11 18l-6-6 6-6"/></svg>
    Torna alla dashboard
  </a>
  <h1 class="section-title" style="margin-top:10px;">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l1.8 4.6L18 8l-4.2 1.4L12 14l-1.8-4.6L6 8l4.2-1.4L12 2Z"/></svg>
    Consigli AI
  </h1>
  <p class="section-sub">Suggerimenti generati automaticamente in base alle ultime letture dei sensori.</p>

  <?php if (empty($impianti)): ?>
    <div class="empty-state">Nessun impianto collegato a questo account.</div>
  <?php endif; ?>

  <?php foreach ($schedeConsigli as $scheda): ?>
    <section class="panel">
      <div class="panel-head"><h2><?= h($scheda['nome']) ?></h2></div>
      <?php foreach ($scheda['consigli'] as $c): ?>
        <div class="advice-card <?= h($c['tipo']) ?>"><?= h($c['testo']) ?></div>
      <?php endforeach; ?>
    </section>
  <?php endforeach; ?>
</div>
</body>
</html>
